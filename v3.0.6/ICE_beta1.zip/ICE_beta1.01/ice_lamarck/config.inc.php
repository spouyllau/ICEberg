<?php
// config file

// bd structure
//
// typebook_xxxx
// book_xxxx
// page_xxxx
//
// données physiques (tableau, images, etc.)
$tablewidth = "850";
?>
