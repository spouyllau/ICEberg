<?php
include("config.inc.php");
include("entete.php");
include("menu.php");
print "
$tablestyle
<tr>
	<td>
	Bienvenue dans ICE.
	</td>
</tr>
</table>";
include("fin_de_page.php");
