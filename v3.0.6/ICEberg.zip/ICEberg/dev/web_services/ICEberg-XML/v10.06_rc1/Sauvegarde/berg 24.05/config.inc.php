<?php
// /////////////////////////////////////////////
// ICEberg v. 1.0
// author : Stephane POUYLLAU, CRHST/CNRS
// s.pouyllau@cite-sciences.fr
// /////////////////////////////////////////////
//Configuration XML$ficTypesBook = "TypeOfBook.xml";$ficBook = "Book.xml";$icorpuspic_tab = "../i-corpuspic/tab/";$repxml = "xml/";$title = "ICEberg v1.0.1_rc1";
$tablecolor = "#ffffff";
$tablewidth = "850";
$tablestyle = "<table bgcolor=\"$tablecolor\" width=\"$tablewidth\">";

?>
