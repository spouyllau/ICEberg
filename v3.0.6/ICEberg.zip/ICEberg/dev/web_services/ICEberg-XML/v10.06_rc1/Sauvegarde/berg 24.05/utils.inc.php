<?php

function print_rr($tab){
	echo "<pre>";
	print_r($tab);
	echo "</pre>";
}


?>