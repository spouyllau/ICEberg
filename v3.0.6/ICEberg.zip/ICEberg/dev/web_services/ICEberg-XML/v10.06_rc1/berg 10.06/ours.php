<?php
// /////////////////////////////////////////////
// ICEberg v. 1.0
// author : Stephane POUYLLAU, CRHST/CNRS
// s.pouyllau@cite-sciences.fr
// /////////////////////////////////////////////
require("entete.php");
print "
<div align=\"right\">
<h1>$title</h1>
<p>$title est un outil web qui �t� d�velopp� dans le cadre du p�le HSTL du CRHST.</p>";?>
<p>Equipe : <br />
Mod�lisation, programmation, strat�gie : St�phane Pouyllau<br />
R�flexion : Delphine Usal, Vincent Leguy, St�phane Pouyllau<br />
Tests : Delphine Usal<br />
<br />
&copy; CRHST/CNRS/St&eacute;phane POUYLLAU.</p>
<p>
      <a href="http://validator.w3.org/check?uri=referer">	  	  <img src="http://www.w3.org/Icons/valid-xhtml10"
		alt="Valid XHTML 1.0!" height="31" width="88" border="0" /></a>
    </p>
<p>
 <a href="http://jigsaw.w3.org/css-validator/">
  <img style="border:0;width:88px;height:31px"  src="http://jigsaw.w3.org/css-validator/images/vcss"  alt="Valid CSS!">
 </a>
</p>
</div><?php 
require("pieddepage.php");
?>
