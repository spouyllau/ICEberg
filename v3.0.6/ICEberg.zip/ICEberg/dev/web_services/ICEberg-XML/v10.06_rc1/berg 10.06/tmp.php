<?php
// /////////////////////////////////////////////
// ICEberg v. 1.0
// author : Stephane POUYLLAU, CRHST/CNRS
// s.pouyllau@cite-sciences.fr
// /////////////////////////////////////////////
require("entete.php");
print "
<div align=\"left\">\"Au commencement, il n'y avait rien...\"
</div>";
require("pieddepage.php");

?>
