<?php

// fin de page
print "</body>
</html>";

?>