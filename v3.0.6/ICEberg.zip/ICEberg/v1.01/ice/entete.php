<?php
// entete
print "
<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
	<meta name=\"author\" content=\"CRHST/CNRS - Stéphane Pouyllau, IE\" />
	<meta name=\"copyright\" content=\"$year\" />
	<meta name=\"keywords\" content=\"$keywords\" />
	<meta name=\"description\" content=\"$description\" />
	<meta name=\"ROBOTS\" content=\"INDEX; FOLLOW\" />
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />	
	
<link href=\"$url/css/style_web.css\" rel=\"stylesheet\" type=\"text/css\" />
<title>$head_title</title>
</head>
<body bgcolor=\"$bodybgcolor\">";
?>