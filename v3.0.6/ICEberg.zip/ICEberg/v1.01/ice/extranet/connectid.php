<?php
require("config.php"); // fichier de config
$host = "localhost"; // voir h�bergeur
$user = "crhst"; // vide en local
$pass = "ytepobuza"; // vide en local
$bdd = "crhst_i_corpus"; // nom de la BD
$table="".$theme."_session"; // nom de la table
?>