<?php
// fichier de configuration

// site web
$site_title = "Titre";
$head_title = "Titre d'entete";
?>