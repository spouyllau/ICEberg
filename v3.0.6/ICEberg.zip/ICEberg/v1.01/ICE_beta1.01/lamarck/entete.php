<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//FR\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
<?php
// entete
print "
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr\" lang=\"fr\">
<head>
	<meta name=\"author\" content=\"CRHST/CNRS - Stéphane Pouyllau, IE\" />
	<meta name=\"copyright\" content=\"$_GET[year]\" />
	<meta name=\"keywords\" content=\"$keywords\" />
	<meta name=\"description\" content=\"$description\" />
	<meta name=\"ROBOTS\" content=\"INDEX, FOLLOW\" />
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
	<meta http-equiv=\"Content-Type\" content=\"application/xhtml+xml; charset=UTF-8\" />
<link href=\"css/style_web.css\" rel=\"stylesheet\" type=\"text/css\">
<title>$head_title</title>
</head>
<body>";
?>