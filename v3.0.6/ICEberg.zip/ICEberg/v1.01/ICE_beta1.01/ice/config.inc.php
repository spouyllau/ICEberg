<?php
// config file

// bd structure
//
// typebook_xxxx
// book_xxxx
// page_xxxx
//
// couleur
$bodybgcolor = "#ffffff";
$colorf = "#339933";
$colorc = "#FFcccc";
$colori = "#cccccc";
// tableaux
$tablecolor = "#ffffff";
$tablewidth = "850";
$tablestyle = "<table bgcolor=\"$tablecolor\" width=\"860\">";
// site web
$site_title = "Titre";
$head_title = "Titre d'entete";
$year = "2004";
$keywords = "ICE, ICE3";
$description = "ICE : gestion de corpus scientifique";
?>
